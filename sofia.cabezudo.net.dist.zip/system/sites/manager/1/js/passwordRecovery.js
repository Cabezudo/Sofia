const templateLiterals = { "site": { "name": "Manager de Sofía", "shortName": "Manager" }, "themeName": "basic", "theme": { "application": { "container": { "width": { "default": "100vw", "480": "480px", "750": "750px", "1024": "1024px", "1250": "1250px", "1800": "1800px" } }, "color": { "main": "#3F0E40" } }, "title": { "font": { "family": "Arial", "weight": { "default": "bold", "480": "bold", "750": "bold", "1024": "bold", "1250": "bold", "1800": "bold" }, "size": { "default": "26px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" }, "padding": { "default": "20px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "subtitle": { "font": { "family": "Arial", "weight": { "default": "bold", "480": "bold", "750": "bold", "1024": "bold", "1250": "bold", "1800": "bold" }, "size": { "default": "20px", "480": "20px", "750": "20px", "1024": "20px", "1250": "20px", "1800": "20px" }, "padding": { "default": "20px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "text": { "font": { "family": "Roboto Condensed", "size": { "default": "18px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "caption": { "title": { "font": { "family": "Roboto Condensed", "size": { "default": "34px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } }, "option": { "font": { "family": "Roboto Condensed", "size": { "default": "18px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } }, "text": { "font": { "family": "Roboto Condensed", "size": { "default": "22px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } } }, "button": { "red": { "color": "white", "backgroundColor": "#D11250" }, "orange": { "red": { "color": "white", "backgroundColor": "#DB5800" } }, "blue": { "red": { "color": "white", "backgroundColor": "#006899" } }, "green": { "red": { "color": "white", "backgroundColor": "#008F68" } } } }, "passwordRecovery": { "passwordRecoveryTitle": "Recuperar contraseña", "messageTitle": "Correo enviado", "afterPasswordRecoverySent": "index.html", "theme": { "caption": { "title": { "font": { "family": "Roboto Condensed", "size": { "default": "34px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } }, "option": { "font": { "family": "Roboto Condensed", "size": { "default": "18px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } }, "text": { "font": { "family": "Roboto Condensed", "size": { "default": "22px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } } } } } };
/* File: libs/list-1.00.00/list-1.00.00.js */
/* global Core, fetch */

/*
 * Created on: 14/05/2019
 * Author:     Esteban Cabezudo
 *
 */

const list_1_00_00 = async ({ id = null, source = null, filterInputElement = null, cellMaker = null, onClick = null, notLoggedURL = '/' } = {}) => {
  const LIST_CLASS_NAME = "list-1_00_00";
  const SCROLL_TIME_TO_FETCH = 200;
  const RESIZE_TIME_TO_CALCULATE = 200;
  const MESSAGE_BASE_CLASS = "messageBaseClass";
  const MESSAGE_CLASS_MESSAGE = "message";
  const MESSAGE_CLASS_WARNING = "warning";
  const MESSAGE_CLASS_ERROR = "error";
  const NUMBER_OF_OFFSET_RECORDS = 10;
  const STATUS_ATTRIBUTE_NAME = "status";
  const STATUS_PENDING = "pending";
  const STATUS_COMPLETED = "completed";
  const MESSAGE_LOADING_DATA = "Cargando datos para crear lista.";
  const MESSAGE_CREATING_LIST = "Creando lista.";
  const MESSAGE_I_CAN_NOT_CREATE_THE_LIST = "Ha sucedido un error al cargar la lista. Intente mas tarde por favor.";
  const MESSAGE_NO_RECORD_FOUND = "No hay registros en la base de datos";
  const RELOAD_LIST_EVENT_TIME_DELAY = 800;
  let numberOfRecordsPerReading;
  let resizeTimer;
  let lastFilterInputValue = '';
  let reloadTimer;
  let fetchTimer;
  let listElement;
  let tableContainer;
  let filterInput = null;
  let table;
  let tableBody;
  let totalRecords;
  let bodyHeight;
  let rowHeight;
  let firstVisibleRowNumber;
  let lastVisibleRowNumber;
  let visibleRowsNumber;
  let tableScroll;
  const calculateValues = () => {
    bodyHeight = tableBody.offsetHeight;
    const firstRow = tableBody.firstChild;
    rowHeight = firstRow.offsetHeight;
    const tableContainerHeight = tableContainer.offsetHeight;
    visibleRowsNumber = parseInt(tableContainerHeight / rowHeight);
    tableScroll = tableContainer.scrollTop;
    firstVisibleRowNumber = Math.round(tableScroll / rowHeight);
    lastVisibleRowNumber = firstVisibleRowNumber + visibleRowsNumber;
  };
  const loadAllData = () => {
    loadData(firstVisibleRowNumber - NUMBER_OF_OFFSET_RECORDS);
    loadData(lastVisibleRowNumber + NUMBER_OF_OFFSET_RECORDS);
  };
  const loadData = async rowNumber => {
    if (rowNumber < 0) {
      rowNumber = 0;
    }
    const page = Math.floor(rowNumber / numberOfRecordsPerReading);
    const milestoneId = page * numberOfRecordsPerReading;
    if (milestoneId > totalRecords) {
      return;
    }
    const rowId = getRowId(milestoneId);
    const rowElement = document.getElementById(rowId);
    const state = rowElement.getAttribute(STATUS_ATTRIBUTE_NAME);
    if (state === null) {
      fetchData(rowElement, milestoneId);
    }
  };
  const fetchData = (rowElement, start) => {
    rowElement.setAttribute(STATUS_ATTRIBUTE_NAME, STATUS_PENDING);
    let url = `${source}?offset=${start}`;
    return fetch(url)
            .then(response => {
              if (response.ok) {
                return response.json();
              } else {
                return null;
              }
            })
            .then(data => {
              if (data === null) {
                createErrorMessage(MESSAGE_I_CAN_NOT_CREATE_THE_LIST);
                return;
              }
              data.list.forEach(elementData => {
                const rowId = getRowId(elementData.row);
                const tableRow = document.getElementById(rowId);
                addTableData(tableRow, elementData);
                if (Core.isFunction(onClick)) {
                  tableRow.className = 'clickable';
                  tableRow.onclick = event => {
                    onClick(event, elementData);
                  };
                }
              });
              rowElement.setAttribute(STATUS_ATTRIBUTE_NAME, STATUS_COMPLETED);
            });
  };
  const showRecord = recordNumber => {
    newScroll = recordNumber * rowHeight - bodyHeight / 2;
    tableContainer.scrollTop = newScroll;
    tableBodyScroll = newScroll;
  };
  const createMessage = message => {
    abstractMessageCreator(message, MESSAGE_CLASS_MESSAGE);
  };
  const createErrorMessage = message => {
    abstractMessageCreator(message, MESSAGE_CLASS_ERROR);
  };
  const abstractMessageCreator = (message, ...className) => {
    const divMessage = document.createElement("DIV");
    divMessage.classList.add(MESSAGE_BASE_CLASS);
    className.forEach(className => {
      divMessage.classList.add(className);
    });
    Core.removeChilds(tableContainer);
    tableContainer.appendChild(divMessage);
    const messageTextNode = document.createTextNode(message);
    divMessage.appendChild(messageTextNode);
  };
  const addEmptyRow = (rowId) => {
    const tableRow = document.createElement("TR");
    tableRow.id = getRowId(rowId);
    if (Core.isFunction(cellMaker)) {
      const innerHTML = cellMaker();
      tableRow.innerHTML = innerHTML;
    } else {
      removeChilds(tableRow);
      const tableData = document.createElement("TD");
      tableRow.appendChild(tableData);
      const textNode = document.createTextNode('\u00A0');
      tableData.appendChild(textNode);
    }
    tableBody.appendChild(tableRow);
  };
  const addTableData = (tableRow, row) => {
    if (Core.isFunction(cellMaker)) {
      const innerHTML = cellMaker(row);
      tableRow.innerHTML = innerHTML;
    } else {
      removeChilds(tableRow);
      Object.keys(row).forEach(field => {
        if (field === 'row' || field === 'id') {
          return;
        }
        const tableData = document.createElement("TD");
        tableRow.appendChild(tableData);
        const textNode = document.createTextNode(`${row[field]}`);
        tableData.appendChild(textNode);
      });
    }
  };
  const getRowId = rowId => {
    return `${id}:${rowId}`;
  };
  const removeChilds = element => {
    while (element.firstChild) {
      element.removeChild(element.firstChild);
    }
  };
  const validateOptions = () => {
    listElement = Core.validateById(id);
    if (filterInputElement !== null) {
      filterInput = Core.validateElement(filterInputElement);
      if (filterInput.tagName !== 'INPUT') {
        throw new Error(`Can't use a ${filterInput.tagName} as filter input.`);
      }
    }
  };
  const createGUI = async() => {
    tableContainer = document.createElement('DIV');
    listElement.className = LIST_CLASS_NAME;
    listElement.appendChild(tableContainer);
    onresize(event => {
      if (resizeTimer) {
        clearTimeout(resizeTimer);
      }
      resizeTimer = setTimeout(() => {
        calculateValues();
      }, RESIZE_TIME_TO_CALCULATE);
    });
    createMessage(MESSAGE_LOADING_DATA);
    loadTable();
  };
  const loadTable = () => {
    let url = source;
    if (filterInput !== null && filterInput.value !== lastFilterInputValue) {
      lastFilterInputValue = filterInput.value;
      url += `?filters=${encodeURIComponent(filterInput.value)}`;
    }
    tableContainer.scrollTop = 0;

    fetch(`${url}`)
            .then(response => {
              if (response.ok) {
                return response.json();
              } else {
                return null;
              }
            })
            .then(data => {
              if (data === null) {
                createErrorMessage(MESSAGE_I_CAN_NOT_CREATE_THE_LIST);
                return;
              }

              if (data.status === 'NOT_LOGGED_IN') {
                document.location.replace(notLoggedURL);
              }

              totalRecords = data.totalRecords;
              const filters = data.filters;
              if (filterInput !== null) {
                filterInput.value = filters;
                lastFilterInputValue = filters;
              }
              if (totalRecords === 0) {
                createMessage(MESSAGE_NO_RECORD_FOUND);
                return;
              }
              numberOfRecordsPerReading = data.pageSize;
              removeChilds(tableContainer);
              createMessage(MESSAGE_CREATING_LIST);
              table = document.createElement("TABLE");
              tableBody = document.createElement("TBODY");
              table.appendChild(tableBody);
              removeChilds(tableContainer);
              tableContainer.appendChild(table);
              tableContainer.onscroll = event => {
                calculateValues();
                if (fetchTimer) {
                  clearTimeout(fetchTimer);
                }
                fetchTimer = setTimeout(() => {
                  loadAllData();
                }, SCROLL_TIME_TO_FETCH);
              };
              for (let i = 0; i < totalRecords; i++) {
                addEmptyRow(i);
              }
              calculateValues();
              loadAllData();
            });
  };
  const assignTriggers = () => {
    if (filterInput !== null) {
      filterInput.addEventListener('setFilter', event => {
        const data = event.detail;
        filterInput.value = data;
        loadTable();
      });
      filterInput.addEventListener("keyup", event => {
        if (Core.isModifierKey(event) || Core.isNavigationKey(event)) {
          return;
        }
        if (reloadTimer) {
          clearTimeout(reloadTimer);
        }
        reloadTimer = setTimeout(loadTable, RELOAD_LIST_EVENT_TIME_DELAY);
      });
    }
  };
  validateOptions();
  assignTriggers();
  createGUI();
};
/* File: libs/bottomMessages-1.00/bottomMessages-1.00.js */
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global Core */

const bottomMessages_1_00 = ({ id = null, element = null } = {}) => {
  let messageContainer;
  const validateOptions = () => {
    element = Core.validateIdOrElement(id, element);
  };

  const createGUI = () => {
    element.className = 'bottomMessages_1_00';
    Core.setMessagesContainer(element);
    messageContainer = document.createElement('div');
    element.appendChild(messageContainer);
  };

  const assignTriggers = () => {
    element.addEventListener('clearMessages', () => {
      Core.removeChilds(messageContainer);
    });
    element.addEventListener('add', event => {
      messageContainer.style.opacity = 1;
      const data = event.detail;
      messageContainer.innerText = data.message;
      switch (data.status) {
        case 'OK':
          messageContainer.className = 'green';
          break;
        case 'ERROR':
          messageContainer.className = 'red';
          break;
      }
      setTimeout(() => {
        messageContainer.style.opacity = 0;
      }, 6000);
    }
    );
  };
  validateOptions();
  createGUI();
  assignTriggers();

  return element;
};
/* File: libs/inputEMailValidator-1.00.00/inputEMailValidator_1_00_00.js */
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global Core */

const inputEMailValidator_1_00_00 = ({ element = null, onValid = null, onNotValid = null, onKeyPress = null } = {}) => {
  let verificationTimer;
  let requestId = 0;

  const validateOptions = () => {
    if (element === null) {
      throw Error('You must define an element to apply the validator.');
    }
  };
  const createGUI = () => {
    element.className = 'inputEMailValidator_1_00_00';
    if (element.value && element.value.length > 0) {
      sendValidationRequest(element);
    }
  };
  const assignTriggers = () => {
    element.addEventListener('response', event => {
      const data = event.detail;

      const element = event.srcElement;
      if (requestId === data.requestId) {
        Core.cleanMessagesContainer();
        const data = event.detail;
        data.elementId = element.id;
        Core.addMessage(data);
        if (data.status === 'ERROR') {
          element.classList.add('error');
        }
        if (data.status === 'OK') {
          element.classList.remove('error');
          if (Core.isFunction(onValid)) {
            onValid();
          }
        } else {
          if (Core.isFunction(onNotValid)) {
            onNotValid();
          }
        }
      }
    });
    element.addEventListener("keypress", event => {
      if (Core.isFunction(onKeyPress)) {
        onKeyPress(event);
      }
    });
    element.addEventListener("keyup", event => {
      if (Core.isModifierKey(event) || Core.isNavigationKey(event)) {
        return;
      }
      if (verificationTimer) {
        clearTimeout(verificationTimer);
      }
      verificationTimer = setTimeout(sendValidationRequest(element), Core.EVENT_TIME_DELAY);
    });
  };
  const sendValidationRequest = element => {
    const response = Core.sendGet(`/api/v1/mails/${element.value}/validate`, element);
    requestId = response.requestId;
  };

  validateOptions();
  createGUI();
  assignTriggers();
}
;
/* File: libs/editableField-1.00/editableField-1.00.js */
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global Core */

const editableField_1_00 = ({ element = null, id = null, validationURI = null, updateURI = null, field = null, defaultValue = null, onValid = null, onNotValid = null, onUpdate = null } = {}) => {
  let inputElement, saveButton, lastValue, validationTimer, saveTimer, requestId = 0;

  const validateOptions = () => {
    if (element === null && id === null) {
      throw Error('You must define a property id or a property element.');
    }
    if (validationURI === null) {
      throw Error('You must set a web services validationURI.');
    }
    if (updateURI === null) {
      throw Error('You must set a web services storeURI.');
    }
    if (field === null) {
      throw Error('You must add a record field to associate.');
    }
  };
  const createGUI = () => {
    if (element === null) {
      element = Core.validateById(id);
    }
    element.classList.add('editableField-1_00');
    inputElement = document.createElement('input');
    inputElement.setAttribute('type', 'text');
    inputElement.value = defaultValue;
    lastValue = defaultValue;
    element.appendChild(inputElement);
    element.inputElement = inputElement;
    inputElement.data = {validationURI, field};

    saveButton = document.createElement('div');
    element.appendChild(saveButton);
  };
  const sendValidationRequest = event => {
    const inputElement = event.srcElement;
    const data = {
      field: inputElement.data.field,
      value: inputElement.value
    };
    const uri = validationURI.replace('{value}', inputElement.value);
    const response = Core.sendGet(uri, inputElement, data);
    requestId = response.requestId;
  };
  const sendUpdateRequest = () => {
    saveButton.innerHTML = 'Saving...';
    saveButton.className = 'saving';
    const data = {
      field: inputElement.data.field,
      value: inputElement.value
    }
    const response = Core.sendPut(updateURI, inputElement, data);
  };
  const assignTriggers = () => {
    inputElement.addEventListener('response', event => {
      const data = event.detail;
      console.log(data);
      if (data.status === 'OK') {
        if (data.type === 'UPDATE') {
          saveButton.innerHTML = 'Saved';
          saveButton.className = 'saved';
          saveButton.style.opacity = 0;
          saveButton.style.pointerEvents = 'none';
          if (Core.isFunction(onUpdate)) {
            onUpdate();
          }
        }
      }
      if (requestId === data.requestId) {
        Core.cleanMessagesContainer();
        element.classList.remove('error');
        Core.addMessage(data);
        if (data.status === 'ERROR') {
          element.classList.add('error');
        }
        if (data.status === 'OK') {
          if (data.type === 'VALIDATION') {
            saveButton.innerHTML = 'Save';
            saveButton.className = '';
            saveButton.style.opacity = 1;
            saveButton.style.pointerEvents = 'auto';
            saveTimer = setTimeout(event => {
              sendUpdateRequest(event);
            }, 8000);
            if (Core.isFunction(onValid)) {
              onValid();
            }
          }
        } else {
          if (Core.isFunction(onNotValid)) {
            onNotValid();
          }
        }
      }
    });
    const update = event => {
      if (Core.isModifierKey(event) || Core.isNavigationKey(event)) {
        return;
      }
      if (lastValue !== inputElement.value) {
        if (saveTimer) {
          clearTimeout(saveTimer);
        }
        lastValue = inputElement.value;
        if (validationTimer) {
          clearTimeout(validationTimer);
        }
        validationTimer = setTimeout(() => {
          sendValidationRequest(event);
        }, 400);
      }
    };
    sendData = event => {
      const source = event.srcElement;
      const data = source.data;
    };
    element.addEventListener("keyup", event => {
      update(event);
    });
  };
  validateOptions();
  createGUI();
  assignTriggers();
}
;
/* File: libs/button-1.00.00/button_1_00_00.js */
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global Core */

const button_1_00_00 = ({ id = null, element = null, type = null, text = null, enabled = true, onClick = null, onResponse = null } = {}) => {
  const DISABLED_CLASS = 'disabledButton_1_00_00';

  const validateOptions = () => {
    element = Core.validateIdOrElement(id, element);
    id = element.id;
    if (type === null) {
      throw Error('You must specify a button type.');
    }
  };
  const createGUI = () => {
    element.className = 'button_1_00_00';
    element.classList.add(`${type}Button_1_00_00`);
    if (!enabled) {
      element.classList.add(DISABLED_CLASS);
    }
    if (text !== null) {
      element.innerHTML = text;
    } else {
      if (element.innerHTML === '') {
        element.innerHTML = 'Action';
      }
    }
  };
  const assignTriggers = () => {
    element.addEventListener('enabled', () => {
      element.classList.remove(DISABLED_CLASS);
    });
    element.addEventListener('disabled', () => {
      element.classList.add(DISABLED_CLASS);
    });
    element.addEventListener('toggle', () => {
      element.classList.toggle(DISABLED_CLASS);
    });
    element.addEventListener('click', event => {
      if (element.classList.contains(DISABLED_CLASS)) {
        return;
      }
      if (event.button === 0 && Core.isFunction(onClick)) {
        element.classList.add(DISABLED_CLASS);
        onClick();
      }
    });
    element.addEventListener('response', event => {
      if (Core.isFunction(onResponse)) {
        onResponse(event);
      }
      element.classList.remove(DISABLED_CLASS);
    });
  };
  validateOptions();
  createGUI();
  assignTriggers();
  return element;
};
const redButton_1_00_00 = ({ id = null, element = null, text = null, enabled = true, onClick = null, onResponse = null } = {}) => {
  return button_1_00_00({id: id, element: element, type: 'red', text: text, enabled: enabled, onClick: onClick, onResponse: onResponse});
};
const orangeButton_1_00_00 = ({ id = null, element = null, text = null, enabled = true, onClick = null, onResponse = null } = {}) => {
  return button_1_00_00({id: id, element: element, type: 'orange', text: text, enabled: enabled, onClick: onClick, onResponse: onResponse});
};
const blueButton_1_00_00 = ({ id = null, element = null, text = null, enabled = true, onClick = null, onResponse = null } = {}) => {
  return button_1_00_00({id: id, element: element, type: 'blue', text: text, enabled: enabled, onClick: onClick, onResponse: onResponse});
};
const greenButton_1_00_00 = ({ id = null, element = null, text = null, enabled = true, onClick = null, onResponse = null } = {}) => {
  return button_1_00_00({id: id, element: element, type: 'green', text: text, enabled: enabled, onClick: onClick, onResponse: onResponse});
};
/* File: libs/linkTo-1.00.00/linkTo-1.00.00.js */
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

const linkTo_1_00_00 = ({ onClick = null, id = null, element = null } = {}) => {
  const validateOptions = () => {
    if (id !== null) {
      element = Core.validateById(id);
    } else {
      if (element === null) {
        throw Error('You must define a property id or a property element.');
      }
    }
    if (onClick === null) {
      throw Error('You must define a url or function in a property onClick.');
    }
  };
  const createGUI = () => {
    element.classList.add('linkTo-1_00_00');
    element.onclick = () => {
      if (typeof onClick === 'function') {
        onClick(this);
      } else {
        document.location.href = onClick;
      }
    };
  };
  const assignTriggers = () => {
  };
  validateOptions();
  createGUI();
  assignTriggers();
}
;
/* File: libs/inputPasswordPairValidator-1.00.00/inputPasswordPairValidator-1.00.00.js */
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global Core */

const inputPasswordPairValidator_1_00_00 = ({ element = null, repetitionElement = null, onValid = null, onNotValid = null, onKeyPress = null } = {}) => {

  const validateOptions = () => {
    if (element === null) {
      throw Error('You must define a input password element to apply the validator.');
    }
    if (repetitionElement === null) {
      throw Error('You must define a input password repetitionElement to apply the validator.');
    }
  };
  const createGUI = () => {
    element.className = 'inputPasswordPairValidator_1_00_00';
    repetitionElement.className = 'inputPasswordPairValidator_1_00_00';
  };
  const assignTriggers = () => {
    element.addEventListener('response', event => {
      const data = event.detail;
      Core.cleanMessagesContainer();
      const messages = event.detail.messages;
      element.classList.remove('error');
      messages.forEach(message => {
        Core.addMessage(message);
        if (message.type === 'ERROR') {
          element.classList.add('error');
        }
        if (message.status === 'VALID') {
          if (Core.isFunction(onValid)) {
            onValid();
          }
        } else {
          if (Core.isFunction(onNotValid)) {
            onNotValid();
          }
        }
      });
    });
    element.addEventListener("keypress", event => {
      if (Core.isFunction(onKeyPress)) {
        onKeyPress(event);
      }
    });
    repetitionElement.addEventListener("keypress", event => {
      if (Core.isFunction(onKeyPress)) {
        onKeyPress(event);
      }
    });
    const keyUpEvent = event => {
      if (Core.isModifierKey(event) || Core.isNavigationKey(event)) {
        return;
      }
      sendVerificationRequest();
    };
    element.addEventListener("keyup", event => {
      keyUpEvent(event);
    });
    repetitionElement.addEventListener("keyup", event => {
      keyUpEvent(event);
    });
  };
  const sendVerificationRequest = () => {
    Core.sendPost(`/api/v1/password/pair/validate`, element, {password: btoa(element.value), repetitionPassword: btoa(repetitionElement.value)});
  };
  validateOptions();
  createGUI();
  assignTriggers();
}
;
/* File: libs/inputPasswordValidator-1.00.00/inputPasswordValidator_1_00_00.js */
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global Core */

const inputPasswordValidator_1_00_00 = ({ element = null, onValid = null, onNotValid = null, onKeyPress = null } = {}) => {
  let requestId = 0;
  let verificationTimer;

  const validateOptions = () => {
    if (element === null) {
      throw Error('You must define an element to apply the validator.');
    }
  };
  const createGUI = () => {
    element.className = 'inputPasswordValidator_1_00_00';
  };
  const assignTriggers = () => {
    element.addEventListener('response', event => {
      const data = event.detail;

      const element = event.srcElement;
      if (requestId === data.requestId) {
        Core.cleanMessagesContainer();
        data.elementId = element.id;
        if (data.status === 'ERROR') {
          Core.addMessage(data);
          element.classList.add('error');
        }
        if (data.status === 'OK') {
          element.classList.remove('error');
          Core.addMessage(data);
          if (Core.isFunction(onValid)) {
            onValid();
          }
        } else {
          if (Core.isFunction(onNotValid)) {
            onNotValid();
          }
        }
      }
    });
    element.addEventListener("keypress", event => {
      if (Core.isFunction(onKeyPress)) {
        onKeyPress(event);
      }
    });
    element.addEventListener("keyup", event => {
      if (Core.isModifierKey(event) || Core.isNavigationKey(event)) {
        return;
      }
      if (verificationTimer) {
        clearTimeout(verificationTimer);
      }
      verificationTimer = setTimeout(sendVerificationRequest, 300);
    });
  };
  const sendVerificationRequest = () => {
    const response = Core.sendPost(`/api/v1/password/validate`, element, {password: btoa(element.value)});
    requestId = response.requestId;
  };
  validateOptions();
  createGUI();
  assignTriggers();
}
;
/* File: libs/core/core-1.00.00.ws.js */
const WEB_SOCKET_URL = null;

const onloadFunctionList = [];
const onresizeFunctionList = [];

let webSocketURL;
let webSocketAvailable = false;

const webSocketSupport =
  ("WebSocket" in window && window.WebSocket != undefined) || ("MozWebSocket" in window && navigator.userAgent.indexOf("Android") === -1);

const onload = functionToRun => {
  onloadFunctionList.push(functionToRun);
};

const onresize = functionToRun => {
  onresizeFunctionList.push(functionToRun);
};

const openWebsocket = () => {
  if (WEB_SOCKET_URL === null) {
    const location = window.location;
    let port = "";
    if (location.port !== "") {
      port = `:${location.port}`;
    }
    webSocketURL = `wss://${location.host}${port}`;
  } else {
    webSocketURL = WEB_SOCKET_URL;
  }

  try {
    socket = new WebSocket(webSocketURL);
    socket.onopen = () => {};
    socket.onerror = error => {
      webSocketAvailable = false;
    };
    socket.onmessage = message => {
      console.info("Message: %o", message.data);
    };
    webSocketAvailable = socket.readyState === WebSocket.OPEN;
  } catch (e) {
    webSocketAvailable = false;
  }
};

window.onresize = event => {
  onresizeFunctionList.forEach(functionToRun => {
    functionToRun(event);
  });
};

window.onload = event => {
  openWebsocket();

  onloadFunctionList.forEach(functionToRun => {
    functionToRun(event);
  });
};
/* File: libs/core/core-1.00.00.js */
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global fetch */
/* global postData */
/* global variables */

'use strict';
const Core = {
  messagesContainer: null,
  requestId: 0,
  onloadFunctions: [],
  screenBlockerDiv: null,
  pageParameters: new URLSearchParams(location.search),
  lastSection: null,
  addMessage: message => {
    if (Core.messagesContainer) {
      Core.trigger(Core.messagesContainer, 'add', message);
    }
  }
  ,
  addOnloadFunction: (func) => {
    Core.onloadFunctions.push(func);
  },
  changeSection: section => {
    if (Core.lastSection !== null) {
      Core.hide(Core.lastSection);
      Core.show(section);
    }
  },
  cleanMessagesContainer: () => {
    if (Core.messagesContainer) {
      Core.trigger(Core.messagesContainer, 'clearMessages');
    }
  },
  getNextRequestId: () => {
    return Core.requestId++;
  },
  getRequestId: () => {
    return Core.requestId;
  },
  getURLParameterByName: (name, url) => {
    if (!url) {
      url = window.location.href;
    }
    name = name.replace(/[\[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
    const results = regex.exec(url);
    if (!results) {
      return null;
    }
    if (!results[2]) {
      return '';
    }
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  },
  hide: (id) => {
    const element = typeof id === 'string' ? document.getElementById(id) : id;
    element.hidden = true;
    Core.trigger(element, 'hide');
//    if (!element.style.display) {
//      element.setAttribute('lastDisplay', element.style.display);
//    }
//    element.style.display = 'none';
  },
  isEnter: event => {
    return event.key === 'Enter';
  },
  isFunction: v => {
    return Object.prototype.toString.call(v) === '[object Function]';
  },
  isLogged: () => {
    return !Core.isNotLogged();
  },
  isModifierKey: event => {
    const key = event.key;
    switch (key) {
      case "Alt":
      case "AltGraph":
      case "CapsLock":
      case "Control":
      case "Fn":
      case "FnLock":
      case "Hyper":
      case "Meta":
      case "NumLock":
      case "ScrollLock":
      case "Shift":
      case "Super":
      case "Symbol":
      case "SymbolLock":
        return true;
      default:
        return false;
    }
  },
  isNavigationKey: event => {
    const key = event.key;
    switch (key) {
      case 'Up':
      case 'ArrowUp':
      case 'Right':
      case 'ArrowRight':
      case 'Down':
      case 'ArrowDown':
      case 'Left':
      case 'ArrowLeft':
      case 'End':
      case 'Home':
      case 'PageDown':
      case 'PageUp':
        return true;
      default:
        return false;
    }
  },
  isNotLogged: () => {
    return variables.user === null;
  },
  isRightLeft: event => {
    return (typeof event === 'object' && event.button === 0);
  },
  isRightClick: event => {
    return (typeof event === 'object' && event.button === 2);
  },
  isTouchStart: event => {
    return true;
  },
  isVisible: element => {
    return !element.hidden;
  },
  removeChilds: element => {
    while (element.firstChild) {
      element.removeChild(element.firstChild);
    }
  },
  screenBlocker: {
    create: () => {
      if (!Core.screenBlockerDiv) {
        Core.screenBlockerDiv = document.getElementById('screenBlocker');
        if (!Core.screenBlockerDiv) {
          Core.screenBlockerDiv = document.createElement("div");
          Core.screenBlockerDiv.id = 'screenBlocker';
          Core.screenBlockerDiv.style.position = "absolute";
          Core.screenBlockerDiv.style.top = "0px";
          Core.screenBlockerDiv.style.width = "100vw";
          Core.screenBlockerDiv.style.height = "100vh";
          Core.screenBlockerDiv.style.background = "gray";
          Core.screenBlockerDiv.style.opacity = ".7";
          Core.screenBlockerDiv.focus();
          document.body.appendChild(Core.screenBlockerDiv);
        }
      } else {
        Core.screenBlockerDiv.style.display = "block";
      }
    },
    block: () => {
      Core.screenBlocker.create();
      Core.screenBlockerDiv.style.display = "block";
    },
    unblock: (options) => {
      Core.screenBlocker.create();
      Core.screenBlockerDiv.style.display = "none";
      if (options && options.focus) {
        options.focus.focus();
      }
    }
  },
  sendGet: (url, origin) => {
    if (!origin) {
      throw new Error(`Invalid origin for sendGet: ${origin}`);
    }
    const requestId = Core.getNextRequestId();
    fetch(url, {
      headers: {
        "Content-Type": "application/json",
        "RequestId": requestId
      }
    })
            .then(function (response) {
              const headers = response.headers;
              const requestId = parseInt(headers.get('RequestId'));
              response.json().then(jsonData => {
                jsonData.requestId = requestId;
                Core.trigger(origin, 'response', jsonData);
              });
            })
            ;
    return {requestId};
  },
  sendPost: (url, origin, formObject) => {
    if (!origin) {
      throw new Error(`Invalid origin for sendGet: ${origin}`);
    }
    const requestId = Core.getNextRequestId();
    fetch(url, {
      method: "POST",
      cache: "no-cache",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "RequestId": requestId
      },
      redirect: "follow",
      body: JSON.stringify(formObject)
    })
            .then(function (response) {
              const headers = response.headers;
              const requestId = parseInt(headers.get('RequestId'));
              response.json().then(jsonData => {
                jsonData.requestId = requestId;
                Core.trigger(origin, 'response', jsonData);
              });
            })
            ;
    return {requestId};
  },
  sendPut: (url, origin, formObject) => {
    if (!origin) {
      throw new Error(`Invalid origin for sendGet: ${origin}`);
    }
    const requestId = Core.getNextRequestId();
    fetch(url, {
      method: "PUT",
      cache: "no-cache",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "RequestId": requestId
      },
      redirect: "follow",
      body: JSON.stringify(formObject)
    })
            .then(function (response) {
              const headers = response.headers;
              const requestId = parseInt(headers.get('RequestId'));
              response.json().then(jsonData => {
                jsonData.requestId = requestId;
                Core.trigger(origin, 'response', jsonData);
              });
            })
            ;
    return {requestId};
  },
  setMessagesContainer: target => {
    Core.messagesContainer = typeof target === 'string' ? document.getElementById(target) : target;
  },
  show: (id) => {
    const element = typeof id === 'string' ? document.getElementById(id) : id;
    element.hidden = false;
    Core.trigger(element, 'show');
//    const display = element.getAttribute('lastDisplay');
//    if (display) {
//      element.style.display = display;
//    } else {
//      element.style.display = '';
//    }
  },
  trigger: (target, eventName, detail) => {
    const event = new CustomEvent(eventName, {detail});
    target.dispatchEvent(event);
  },
  validateById: (id) => {
    if (id === null) {
      throw new Error(`You must specify a valid id: ${id}`);
    }
    const element = document.getElementById(id);
    if (element === null) {
      throw new Error(`Can't find the element with the id ${id}.`);
    }
    return element;
  },
  validateElement: (element) => {
    if (element === null) {
      throw new Error(`The parameter element is null.`);
    }
    if (!element.tagName) {
      throw new Error(`The node is not an element.`);
    }
    return element;
  },
  validateIdOrElement: (id, element) => {
    if (id === null && element === null) {
      throw new Error(`You must specify an id or element.`);
    }
    if (id !== null && element !== null && element.id !== id) {
      throw new Error(`The element and the id don't belong to the same element.`);
    }
    if (id !== null) {
      return Core.validateById(id);
    }
    if (element !== null) {
      return Core.validateElement(element);
    }
  }
};

window.onload = () => {
  Core.onloadFunctions.forEach(func => {
    func();
  });
  if (Core.pageParameters.has('section')) {
    Core.changeSection(Core.pageParameters.get('section'));
  }
};
/* File: libs/simpleStaticMessages-1.00/simpleStaticMessages-1.00.js */
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global Core */

const simpleStaticMessages_1_00 = ({ id = null, element = null } = {}) => {
  let messageContainer;
  let messages = {};

  const validateOptions = () => {
    element = Core.validateIdOrElement(id, element);
  };
  const createGUI = () => {
    element.className = 'simpleStaticMessages_1_00';
    Core.setMessagesContainer(element);
  };
  const assignTriggers = () => {
    element.addEventListener('clearMessages', () => {
      Core.removeChilds(element);
    });
    element.addEventListener('add', event => {
      const payload = event.detail;
      if (payload.elementId === undefined) {
        throw new Error('Undefined elementId property for message container.');
      }
      if (payload.status === 'ERROR') {
        messages[payload.elementId] = payload;
      } else {
        delete messages[payload.elementId];
      }
      if (Object.keys(messages).length > 0) {
        messageContainer = document.createElement('div');
        for (var key in messages) {
          messageContainer.className = 'red';
          messageContainer.innerText = messages[key].message;
          break;
        }
        element.appendChild(messageContainer);
      } else {
        Core.removeChilds(element);
      }
    });
  };
  validateOptions();
  createGUI();
  assignTriggers();
  return element;
};
      const login = (() => {
        const createGUI = () => {
        };
        Core.addOnloadFunction(createGUI);
      })();
  const loginForm = (() => {
    let passwordRecoveryEMailElement;
    let passwordRecoverySendButton;
    let validEMail = false;

    const changeAcceptButton = () => {
      if (validEMail) {
        Core.trigger(passwordRecoverySendButton, 'enabled');
        Core.cleanMessagesContainer();
      } else {
        Core.trigger(passwordRecoverySendButton, 'disabled');
      }
    };

    const createGUI = () => {
      Core.show('passwordRecoveryFormContainer');
      Core.hide('passwordRecoveryMessageContainer');
      passwordRecoveryEMailElement = Core.validateById('passwordRecoveryEMail');
      passwordRecoverySendButton = Core.validateById('passwordRecoverySendButton');

      inputEMailValidator_1_00_00({
        element: passwordRecoveryEMailElement,
        onValid: () => {
          validEMail = true;
          changeAcceptButton();
        },
        onNotValid: () => {
          validEMail = false;
          changeAcceptButton();
        },
        onKeyPress: event => {
          if (Core.isEnter(event)) {
            sendPasswordRecoveryInformation();
          }
        }
      });

      greenButton_1_00_00({
        id: 'passwordRecoverySendButton',
        enabled: false,
        onClick: () => {
          sendPasswordRecoveryInformation();
        },
        onResponse: event => {
          Core.screenBlocker.unblock({
            focus: passwordRecoveryEMailElement
          });
          const data = event.detail;
          if (data.status === 'OK') {
            Core.hide('passwordRecoveryFormContainer');
            const message = Core.validateById('passwordRecoveryMessage');
            message.innerHTML = data.message;
            Core.show('passwordRecoveryMessageContainer');
          } else {
            Core.cleanMessagesContainer();
            Core.addMessage(data.messages[0]);
          }
        }
      });
      messages_1_00_00({
        id: 'passwordRecoveryMessages'
      });
      const sendPasswordRecoveryInformation = () => {
        Core.screenBlocker.block();
        const  email = passwordRecoveryEMailElement.value;
        const passwordRecoverySendButton = Core.validateById('passwordRecoverySendButton');
        Core.sendGet(`/api/v1/users/${email}/password/recover`, passwordRecoverySendButton);
      };

      greenButton_1_00_00({
        id: 'passwordRecoveryAcceptButton',
        onClick: () => {
          location.assign('index.html');
        }
      });

      passwordRecoveryEMailElement.focus();
    };
    Core.addOnloadFunction(createGUI);
  })();

