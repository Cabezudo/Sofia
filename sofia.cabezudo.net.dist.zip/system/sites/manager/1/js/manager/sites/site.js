const templateVariables = { "site": { "name": "Manager de Sofía", "shortName": "Sofia" }, "themeName": "basic", "theme": { "application": { "container": { "width": { "default": "100vw", "480": "480px", "750": "750px", "1024": "1024px", "1250": "1250px", "1800": "1800px" }, "padding": { "top": { "default": "40px" }, "right": { "default": "30px" }, "bottom": { "default": "40px" }, "left": { "default": "30px" } } }, "color": { "main": "#2980B9" } }, "menu": { "font": { "size": { "default": "16px" } } }, "title": { "font": { "family": "Arial", "weight": { "default": "bold", "480": "bold", "750": "bold", "1024": "bold", "1250": "bold", "1800": "bold" }, "size": { "default": "26px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" }, "padding": { "default": "20px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "subtitle": { "font": { "family": "Arial", "weight": { "default": "bold", "480": "bold", "750": "bold", "1024": "bold", "1250": "bold", "1800": "bold" }, "size": { "default": "20px", "480": "20px", "750": "20px", "1024": "20px", "1250": "20px", "1800": "20px" }, "padding": { "default": "20px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "messages": { "font": { "family": "'Ubuntu', sans-serif" }, "ok": { "color": "#3D904A" }, "message": { "color": "#3D4590" }, "error": { "color": "#B1001C" } } }, "text": { "font": { "family": "Roboto Condensed", "size": { "default": "18px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "caption": { "title": { "font": { "family": "Roboto Condensed", "size": { "default": "34px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } }, "option": { "font": { "family": "Roboto Condensed", "size": { "default": "18px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } }, "text": { "font": { "family": "Roboto Condensed", "size": { "default": "22px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } } }, "button": { "red": { "color": "white", "backgroundColor": "#D11250" }, "orange": { "red": { "color": "white", "backgroundColor": "#DB5800" } }, "blue": { "red": { "color": "white", "backgroundColor": "#006899" } }, "green": { "red": { "color": "white", "backgroundColor": "#008F68" } } }, "header": { "menu": { "name": "Sofia", "description": "web for people", "items": [ { "name": { "es": "Inicio" }, "url": "../index.html" }, { "name": { "es": "Listado" }, "url": "sites.html" }, { "name": { "es": "Agregar" }, "url": "add.html" }, { "svg": { "viewBox": "0 0 512 512", "path": { "fill": "currentColor", "d": "M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z" } }, "url": "sites.html" } ], "font": { "size": { "default": "16px" } } }, "application": { "container": { "width": { "default": "100vw", "480": "480px", "750": "750px", "1024": "1024px", "1250": "1250px", "1800": "1800px" }, "padding": { "top": { "default": "10px" }, "right": { "default": "30px" }, "bottom": { "default": "10px" }, "left": { "default": "30px" } } }, "title": { "font": { "font-family": [ "Titillium Web", "sans-serif" ] } }, "color": { "main": "#2980B9" } } }, "messages": { "message": { "default": "No message defined" } } };
// Library core/0.1.0 addeded by system.
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global fetch */
/* global postData */
/* global variables */

'use strict';
const Core = {
  messagesContainer: null,
  requestId: 0,
  onloadFunctions: [],
  setPageFunctions: [],
  testFunctions: [],
  screenBlockerDiv: null,
  loaderDiv: null,
  pageParameters: new URLSearchParams(location.search),
  lastSection: null,
  showMessage: (messageObject) => {
    if (Core.messagesContainer !== null) {
      Core.trigger(Core.messagesContainer, 'showMessage', messageObject);
    } else {
      throw new Error('No messages container defined.');
    }
  },
  addOnloadFunction: (func) => {
    Core.onloadFunctions.push(func);
  },
  addSetFunction: (func) => {
    Core.setPageFunctions.push(func);
  },
  changeSection: section => {
    if (Core.lastSection !== null) {
      Core.hide(Core.lastSection);
      Core.show(section);
    }
  },
  cleanMessagesContainer: () => {
    if (Core.messagesContainer) {
      Core.trigger(Core.messagesContainer, 'cleanMessages');
    }
  },
  getNextRequestId: () => {
    return Core.requestId++;
  },
  getRequestId: () => {
    return Core.requestId;
  },
  getURLParameterByName: (name, url) => {
    if (!url) {
      url = window.location.href;
    }
    name = name.replace(/[\[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
    const results = regex.exec(url);
    if (!results) {
      return null;
    }
    if (!results[2]) {
      return '';
    }
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  },
  hide: (id) => {
    const element = typeof id === 'string' ? document.getElementById(id) : id;
    element.hidden = true;
    Core.trigger(element, 'hide');
//    if (!element.style.display) {
//      element.setAttribute('lastDisplay', element.style.display);
//    }
//    element.style.display = 'none';
  },
  inFocus: element => {
    return element === document.activeElement;
  },
  isEnter: event => {
    return event.key === 'Enter';
  },
  isFunction: v => {
    return Object.prototype.toString.call(v) === '[object Function]';
  },
  isLogged: () => {
    return !Core.isNotLogged();
  },
  isModifierKey: event => {
    const key = event.key;
    switch (key) {
      case "Alt":
      case "AltGraph":
      case "CapsLock":
      case "Control":
      case "Fn":
      case "FnLock":
      case "Hyper":
      case "Meta":
      case "NumLock":
      case "ScrollLock":
      case "Shift":
      case "Super":
      case "Symbol":
      case "SymbolLock":
        return true;
      default:
        return false;
    }
  },
  isNavigationKey: event => {
    const key = event.key;
    switch (key) {
      case 'Up':
      case 'ArrowUp':
      case 'Right':
      case 'ArrowRight':
      case 'Down':
      case 'ArrowDown':
      case 'Left':
      case 'ArrowLeft':
      case 'End':
      case 'Home':
      case 'PageDown':
      case 'PageUp':
      case 'Tab':
        return true;
      default:
        return false;
    }
  },
  isNotLogged: () => {
    return variables.user === null;
  },
  isRightLeft: event => {
    return (typeof event === 'object' && event.button === 0);
  },
  isRightClick: event => {
    return (typeof event === 'object' && event.button === 2);
  },
  isTouchStart: event => {
    return true;
  },
  isVisible: element => {
    return !element.hidden;
  },
  removeChilds: element => {
    while (element.firstChild) {
      element.removeChild(element.firstChild);
    }
  },
  screenBlocker: {
    create: () => {
      if (!Core.screenBlockerDiv) {
        Core.screenBlockerDiv = document.getElementById('screenBlocker');
        if (!Core.screenBlockerDiv) {
          Core.screenBlockerDiv = document.createElement("div");
          Core.screenBlockerDiv.id = 'screenBlocker';
          Core.screenBlockerDiv.style.position = "absolute";
          Core.screenBlockerDiv.style.top = "0px";
          Core.screenBlockerDiv.style.width = "100vw";
          Core.screenBlockerDiv.style.height = "100vh";
          Core.screenBlockerDiv.style.backgroundColor = "gray";
          Core.screenBlockerDiv.style.opacity = ".7";
          Core.screenBlockerDiv.focus();
          document.body.appendChild(Core.screenBlockerDiv);
        }
      } else {
        Core.screenBlockerDiv.style.display = "block";
      }
    },
    block: () => {
      Core.screenBlocker.create();
      Core.screenBlockerDiv.style.display = "block";
    },
    unblock: (options) => {
      Core.screenBlocker.create();
      Core.screenBlockerDiv.style.display = "none";
      if (options && options.focus) {
        options.focus.focus();
      }
    }
  },
  sendGet: (url, origin) => {
    if (!origin) {
      throw new Error(`Invalid origin for sendGet: ${origin}`);
    }
    const requestId = Core.getNextRequestId();
    fetch(url, {
      headers: {
        "Content-Type": "application/json",
        "RequestId": requestId
      }
    })
            .then(function (response) {
              const headers = response.headers;
              const requestId = parseInt(headers.get('RequestId'));
              response.json().then(jsonData => {
                jsonData.requestId = requestId;
                Core.trigger(origin, 'response', jsonData);
              });
            })
            ;
    return {requestId}
    ;
  },
  sendPost: (url, origin, formObject) => {
    if (!origin) {
      throw new Error(`Invalid origin for sendGet: ${origin}`);
    }
    const requestId = Core.getNextRequestId();
    fetch(url, {
      method: "POST",
      cache: "no-cache",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "RequestId": requestId
      },
      redirect: "follow",
      body: JSON.stringify(formObject)
    })
            .then(function (response) {
              if (response.status === 200) {
                const headers = response.headers;
                const requestId = parseInt(headers.get('RequestId'));
                response.json().then(jsonData => {
                  jsonData.requestId = requestId;
                  Core.trigger(origin, 'response', jsonData);
                });
              }
            })
            ;
    return {requestId};
  },
  sendPut: (url, origin, formObject) => {
    if (!origin) {
      throw new Error(`Invalid origin for sendGet: ${origin}`);
    }
    const requestId = Core.getNextRequestId();
    fetch(url, {
      method: "PUT",
      cache: "no-cache",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "RequestId": requestId
      },
      redirect: "follow",
      body: JSON.stringify(formObject)
    })
            .then(function (response) {
              const headers = response.headers;
              const requestId = parseInt(headers.get('RequestId'));
              response.json().then(jsonData => {
                jsonData.requestId = requestId;
                Core.trigger(origin, 'response', jsonData);
              });
            })
            ;
    return {requestId};
  },
  setDefaultMessage: message => {
    if (Core.messagesContainer !== null) {
      Core.trigger(Core.messagesContainer, 'setDefaultMessage', message);
    } else {
      throw new Error('No messages container defined.');
    }
  },
  setMessagesContainer: target => {
    Core.messagesContainer = typeof target === 'string' ? document.getElementById(target) : target;
    console.log(`Core : setMessagesContainer : Set to ${Core.messagesContainer.id}`);
  },
  show: (id) => {
    const element = typeof id === 'string' ? document.getElementById(id) : id;
    element.hidden = false;
    Core.trigger(element, 'show');
//    const display = element.getAttribute('lastDisplay');
//    if (display) {
//      element.style.display = display;
//    } else {
//      element.style.display = '';
//    }
  },
  tests: {
    add: testFunction => {
      Core.testFunctions.push(testFunction);
    }
  },
  trigger: (target, eventName, detail) => {
    console.log(`Core : trigger : Event ${eventName} to ${target.id} using data ${JSON.stringify(detail)}`);
    const event = new CustomEvent(eventName, {detail});
    target.dispatchEvent(event);
  },
  validateById: (id) => {
    if (id === null) {
      throw new Error(`You must specify a valid id: ${id}`);
    }
    const element = document.getElementById(id);
    if (element === null) {
      throw new Error(`Can't find the element with the id ${id}.`);
    }
    return element;
  },
  validateElement: (element) => {
    if (element === null) {
      throw new Error(`The parameter element is null.`);
    }
    if (!element.tagName) {
      throw new Error(`The node is not an element.`);
    }
    return element;
  },
  validateIdOrElement: (id, element) => {
    if (id === null && element === null) {
      throw new Error(`You must specify an id or element.`);
    }
    if (id !== null && element !== null && element.id !== id) {
      throw new Error(`The element and the id don't belong to the same element.`);
    }
    if (id !== null) {
      return Core.validateById(id);
    }
    if (element !== null) {
      return Core.validateElement(element);
    }
  }
};
window.onload = () => {
  Core.onloadFunctions.forEach(func => {
    func();
  });
  Core.setPageFunctions.forEach(func => {
    func();
  });
  if (Core.pageParameters.has('section')) {
    Core.changeSection(Core.pageParameters.get('section'));
  }
  document.body.style.opacity = "1";
  Core.testFunctions.forEach(func => {
    func();
  });
};

// Library editableField/0.1.0 addeded by system.
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global Core */

const editableField = ({ element = null, id = null, validationURI = null, updateURI = null, field = null, defaultValue = null, onValid = null, onNotValid = null, onUpdate = null } = {}) => {
  let inputElement, saveButton, lastValue, validationTimer, saveTimer, requestId = 0;

  const validateOptions = () => {
    if (element === null && id === null) {
      throw Error('You must define a property id or a property element.');
    }
    if (validationURI === null) {
      throw Error('You must set a web services validationURI.');
    }
    if (updateURI === null) {
      throw Error('You must set a web services storeURI.');
    }
    if (field === null) {
      throw Error('You must add a record field to associate.');
    }
  };
  const createGUI = () => {
    if (element === null) {
      element = Core.validateById(id);
    }
    element.classList.add('editableField');
    inputElement = document.createElement('input');
    inputElement.setAttribute('type', 'text');
    inputElement.value = defaultValue;
    lastValue = defaultValue;
    element.appendChild(inputElement);
    element.inputElement = inputElement;
    inputElement.data = {validationURI, field};

    saveButton = document.createElement('div');
    element.appendChild(saveButton);
  };
  const sendValidationRequest = event => {
    const inputElement = event.srcElement;
    const data = {
      field: inputElement.data.field,
      value: inputElement.value
    };
    const uri = validationURI.replace('{value}', inputElement.value);
    const response = Core.sendGet(uri, inputElement, data);
    requestId = response.requestId;
  };
  const sendUpdateRequest = () => {
    saveButton.innerHTML = 'Saving...';
    saveButton.className = 'saving';
    const data = {
      field: inputElement.data.field,
      value: inputElement.value
    }
    const response = Core.sendPut(updateURI, inputElement, data);
  };
  const assignTriggers = () => {
    inputElement.addEventListener('response', event => {
      const data = event.detail;
      console.log(data);
      if (data.status === 'OK') {
        if (data.type === 'UPDATE') {
          saveButton.innerHTML = 'Saved';
          saveButton.className = 'saved';
          saveButton.style.opacity = 0;
          saveButton.style.pointerEvents = 'none';
          if (Core.isFunction(onUpdate)) {
            onUpdate();
          }
        }
      }
      if (requestId === data.requestId) {
        element.classList.remove('error');
        Core.showMessage(data);
        if (data.status === 'ERROR') {
          element.classList.add('error');
        }
        if (data.status === 'OK') {
          if (data.type === 'VALIDATION') {
            saveButton.innerHTML = 'Save';
            saveButton.className = '';
            saveButton.style.opacity = 1;
            saveButton.style.pointerEvents = 'auto';
            saveTimer = setTimeout(event => {
              sendUpdateRequest(event);
            }, 8000);
            if (Core.isFunction(onValid)) {
              onValid();
            }
          }
        } else {
          if (Core.isFunction(onNotValid)) {
            onNotValid();
          }
        }
      }
    });
    const update = event => {
      if (Core.isModifierKey(event) || Core.isNavigationKey(event)) {
        return;
      }
      if (lastValue !== inputElement.value) {
        if (saveTimer) {
          clearTimeout(saveTimer);
        }
        lastValue = inputElement.value;
        if (validationTimer) {
          clearTimeout(validationTimer);
        }
        validationTimer = setTimeout(() => {
          sendValidationRequest(event);
        }, 400);
      }
    };
    sendData = event => {
      const source = event.srcElement;
      const data = source.data;
    };
    element.addEventListener("keyup", event => {
      update(event);
    });
  };
  validateOptions();
  createGUI();
  assignTriggers();
}
;

// Library bottomMessages/0.1.0 addeded by system.
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global Core */

const bottomMessages = ({ id = null, element = null } = {}) => {
  let messageContainer;
  const validateOptions = () => {
    element = Core.validateIdOrElement(id, element);
  };

  const createGUI = () => {
    element.className = 'bottomMessages';
    Core.setMessagesContainer(element);
    messageContainer = document.createElement('div');
    element.appendChild(messageContainer);
  };

  const assignTriggers = () => {
    element.addEventListener('clearMessages', () => {
      Core.removeChilds(messageContainer);
    });
    element.addEventListener('add', event => {
      messageContainer.style.opacity = 1;
      const data = event.detail;
      messageContainer.innerText = data.message;
      switch (data.status) {
        case 'OK':
          messageContainer.className = 'green';
          break;
        case 'ERROR':
          messageContainer.className = 'red';
          break;
      }
      setTimeout(() => {
        messageContainer.style.opacity = 0;
      }, 6000);
    }
    );
  };
  validateOptions();
  createGUI();
  assignTriggers();

  return element;
};

// Library linkTo/0.1.0 addeded by system.
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global Core */

const linkTo = ({ onClick = null, id = null, element = null } = {}) => {
  const validateOptions = () => {
    if (id !== null) {
      element = Core.validateById(id);
    } else {
      if (element === null) {
        throw Error('You must define a property id or a property element.');
      }
    }
    if (onClick === null) {
      throw Error('You must define a url or function in a property onClick.');
    }
  };
  const createGUI = () => {
    element.classList.add('linkTo');
    element.onclick = () => {
      if (typeof onClick === 'function') {
        onClick(this);
      } else {
        document.location.href = onClick;
      }
    };
  };
  const assignTriggers = () => {
  };
  validateOptions();
  createGUI();
  assignTriggers();
}
;

// Library simpleStaticMessage/0.1.0 addeded by system.
/*
 * Created on: 29/10/2019
 * Author:     Esteban Cabezudo
 */

/* global Core */

const simpleStaticMessage = ({ id = null, element = null, onShow = null } = {}) => {
  let
          defaultMessage,
          messageContainer;
  const validateOptions = () => {
    element = Core.validateIdOrElement(id, element);
  };
  const createGUI = () => {
    element.className = 'simpleStaticMessage';
    Core.setMessagesContainer(element);
    defaultMessage = element.innerHTML;
    Core.removeChilds(element);
    messageContainer = document.createElement('div');
    messageContainer.innerText = defaultMessage;
    element.appendChild(messageContainer);
  };
  const clearMessage = () => {
    console.log('simpleStaticMessage : clearMessage.');
    messageContainer.innerText = defaultMessage;
    element.classList.remove('red');
    element.classList.remove('green');
  };
  const assignTriggers = () => {
    element.addEventListener('cleanMessages', () => {
      clearMessage();
    });
    element.addEventListener('setDefaultMessage', event => {
      defaultMessage = event.detail;
      console.log(`simpleStaticMessage : trigger: setDefaultMessage : ${defaultMessage}`);
      messageContainer.innerText = defaultMessage;
    });
    element.addEventListener('showMessage', event => {
      const payload = event.detail;
      console.log(`simpleStaticMessage : trigger : showMessage : ${JSON.stringify(payload)}`);
      switch (payload.status) {
        case 'ERROR':
          messageContainer.innerText = payload.message;
          element.classList.remove('ok');
          element.classList.remove('message');
          element.classList.add('error');
          break;
        case 'OK':
          messageContainer.innerText = payload.message;
          element.classList.remove('error');
          element.classList.remove('message');
          element.classList.add('ok');
          break;
        case 'MESSAGE':
          messageContainer.innerText = payload.message;
          element.classList.remove('ok');
          element.classList.remove('error');
          element.classList.add('message');
          break;
        default:
          throw new Error(`Invalid status: ${payload.status}`);
      }
      if (Core.isFunction(onShow)) {
        onShow();
      }
    });
  };
  validateOptions();
  createGUI();
  assignTriggers();
  return element;
};

// created by system using manager/sites/site.html:14.
      {
        const createGUI = () => {
          const detailDiv = Core.validateById('detail');
          detailDiv.addEventListener('response', event => {
            const site = event.detail;
            editableField({
              id: 'siteName',
              validationURI: `/api/v1/sites/${site.id}/names/{value}/validate`,
              updateURI: `/api/v1/sites/${site.id}`,
              field: 'name',
              defaultValue: site.name
            });
            editableField({
              id: 'siteVersion',
              validationURI: `/api/v1/sites/${site.id}/versions/{value}/validate`,
              updateURI: `/api/v1/sites/${site.id}`,
              field: 'version',
              defaultValue: site.version
            });
            const domains = site.domains;
            const domainsElement = document.getElementById('domains');
            domains.forEach(host => {
              const domainsInput = (() => {
                const element = document.createElement('div');
                editableField({
                  element,
                  validationURI: `/api/v1/sites/${site.id}/hosts/${host.id}/names/{value}/validate`,
                  updateURI: `/api/v1/sites/${site.id}/hosts/${host.id}`,
                  field: 'name',
                  defaultValue: host.name
                });
                return element;
              })();
              domainsElement.appendChild(domainsInput);
            });
            Core.screenBlocker.unblock();
          });
          Core.screenBlocker.block();
          Core.sendGet(`/api/v1/sites/${Core.pageParameters.get('id')}`, detailDiv);

          bottomMessages({id: 'messages'});
        };
        Core.addOnloadFunction(createGUI);
      }
// created by system using headers/menu/simple/menu.html:90 called from manager/sites/site.html:63
  {
    const createGUI = () => {
      const items = { "name": "Sofia", "description": "web for people", "items": [ { "name": { "es": "Inicio" }, "url": "../index.html" }, { "name": { "es": "Listado" }, "url": "sites.html" }, { "name": { "es": "Agregar" }, "url": "add.html" }, { "svg": { "viewBox": "0 0 512 512", "path": { "fill": "currentColor", "d": "M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z" } }, "url": "sites.html" } ], "font": { "size": { "default": "16px" } } }.items;
      const menu = Core.validateById('menu');
      for (const i in items) {
        const item = items[i];
        console.log(`item: ${JSON.stringify(item)}`);
        let profileAccepted = false;
        const menuProfiles = item.profiles;
        const user = variables.user;
        if (menuProfiles === undefined) {
          profileAccepted = true;
        } else {
          if (user !== null) {
            const userProfiles = user.profiles;
            if (userProfiles !== undefined) {
              console.log(`userProfiles: ${JSON.stringify(userProfiles)}`);
              userProfiles.forEach(userProfile => {
                if (menuProfiles.includes(userProfile.name)) {
                  profileAccepted = true;
                }
              });
            }
          }
        }
        console.log(`profileAccepted: ${JSON.stringify(profileAccepted)}`);
        const forLogged = item.logged === undefined || item.logged === null || (Core.isLogged() && item.logged === true)
        console.log(`forLogged: ${forLogged}`);
        const forNotLogged = item.logged === undefined || (Core.isNotLogged() && item.logged === false);
        console.log(`forNotLogged: ${forNotLogged}`);
        const hide = item.hide !== undefined && item.hide !== null && item.hide.includes(window.location.pathname);
        const isNotHide = !hide;
        console.log(`isNotHide: ${isNotHide}`);
        console.log(`profileAccepted: ${profileAccepted}`);
        if (forLogged && forNotLogged && isNotHide && profileAccepted) {
          if (item.name !== undefined) {
            const itemElement = document.createElement('div');
            menu.appendChild(itemElement);
            itemElement.className = 'item';
            itemElement.innerHTML = item.name.es;
            linkTo({
              onClick: item.url,
              element: itemElement
            });
          }
          if (item.svg !== undefined) {
            const itemElement = document.createElement('div');
            itemElement.className = 'item icon';
            menu.appendChild(itemElement);

            const svgElement = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svgElement.setAttribute('viewBox', item.svg.viewBox);
            itemElement.appendChild(svgElement);


            const pathElement = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            pathElement.setAttribute('fill', item.svg.path.fill);
            pathElement.setAttribute('d', item.svg.path.d);
            svgElement.appendChild(pathElement);
            linkTo({
              onClick: item.url,
              element: itemElement
            });
          }
        }
      }
    };
    Core.addOnloadFunction(createGUI);
  }
// created by system using messages/section/simple/message.html:2 called from manager/sites/site.html:69
  (() => {
    const createGUI = () => {
      console.log('Create GUI for simpleStaticMessage:0.1.0');
      simpleStaticMessage({id: 'simpleStaticMessage'});
    };
    Core.addOnloadFunction(createGUI);
  })();
