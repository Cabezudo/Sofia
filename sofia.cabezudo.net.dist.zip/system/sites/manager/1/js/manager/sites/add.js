const templateVariables = { "site": { "name": "Manager de Sofía", "shortName": "Manager" }, "themeName": "basic", "theme": { "application": { "container": { "width": { "default": "100vw", "480": "480px", "750": "750px", "1024": "1024px", "1250": "1250px", "1800": "1800px" } }, "color": { "main": "#000474" } }, "title": { "font": { "family": "Arial", "weight": { "default": "bold", "480": "bold", "750": "bold", "1024": "bold", "1250": "bold", "1800": "bold" }, "size": { "default": "26px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" }, "padding": { "default": "20px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "subtitle": { "font": { "family": "Arial", "weight": { "default": "bold", "480": "bold", "750": "bold", "1024": "bold", "1250": "bold", "1800": "bold" }, "size": { "default": "20px", "480": "20px", "750": "20px", "1024": "20px", "1250": "20px", "1800": "20px" }, "padding": { "default": "20px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "messages": { "font": { "family": "'Economica', sans-serif", "size": { "default": "20px", "480": "20px", "750": "20px", "1024": "20px", "1250": "20px", "1800": "20px" }, "padding": { "default": "20px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "text": { "font": { "family": "Roboto Condensed", "size": { "default": "18px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "caption": { "title": { "font": { "family": "Roboto Condensed", "size": { "default": "34px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } }, "option": { "font": { "family": "Roboto Condensed", "size": { "default": "18px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } }, "text": { "font": { "family": "Roboto Condensed", "size": { "default": "22px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } } }, "button": { "red": { "color": "white", "backgroundColor": "#D11250" }, "orange": { "red": { "color": "white", "backgroundColor": "#DB5800" } }, "blue": { "red": { "color": "white", "backgroundColor": "#006899" } }, "green": { "red": { "color": "white", "backgroundColor": "#008F68" } } } }, "messages": { "message": { "default": "" } } };
// Library core/0.1.0 addeded by system.
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global fetch */
/* global postData */
/* global variables */

'use strict';
const Core = {
  messagesContainer: null,
  requestId: 0,
  onloadFunctions: [],
  screenBlockerDiv: null,
  pageParameters: new URLSearchParams(location.search),
  lastSection: null,
  showMessage: (messageObject) => {
    if (Core.messagesContainer !== null) {
      Core.trigger(Core.messagesContainer, 'showMessage', messageObject);
    } else {
      throw new Error('No messages container defined.');
    }
  },
  addOnloadFunction: (func) => {
    Core.onloadFunctions.push(func);
  },
  changeSection: section => {
    if (Core.lastSection !== null) {
      Core.hide(Core.lastSection);
      Core.show(section);
    }
  },
  cleanMessagesContainer: () => {
    if (Core.messagesContainer) {
      Core.trigger(Core.messagesContainer, 'cleanMessages');
    }
  },
  getNextRequestId: () => {
    return Core.requestId++;
  },
  getRequestId: () => {
    return Core.requestId;
  },
  getURLParameterByName: (name, url) => {
    if (!url) {
      url = window.location.href;
    }
    name = name.replace(/[\[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
    const results = regex.exec(url);
    if (!results) {
      return null;
    }
    if (!results[2]) {
      return '';
    }
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  },
  hide: (id) => {
    const element = typeof id === 'string' ? document.getElementById(id) : id;
    element.hidden = true;
    Core.trigger(element, 'hide');
//    if (!element.style.display) {
//      element.setAttribute('lastDisplay', element.style.display);
//    }
//    element.style.display = 'none';
  },
  isEnter: event => {
    return event.key === 'Enter';
  },
  isFunction: v => {
    return Object.prototype.toString.call(v) === '[object Function]';
  },
  isLogged: () => {
    return !Core.isNotLogged();
  },
  isModifierKey: event => {
    const key = event.key;
    switch (key) {
      case "Alt":
      case "AltGraph":
      case "CapsLock":
      case "Control":
      case "Fn":
      case "FnLock":
      case "Hyper":
      case "Meta":
      case "NumLock":
      case "ScrollLock":
      case "Shift":
      case "Super":
      case "Symbol":
      case "SymbolLock":
        return true;
      default:
        return false;
    }
  },
  isNavigationKey: event => {
    const key = event.key;
    switch (key) {
      case 'Up':
      case 'ArrowUp':
      case 'Right':
      case 'ArrowRight':
      case 'Down':
      case 'ArrowDown':
      case 'Left':
      case 'ArrowLeft':
      case 'End':
      case 'Home':
      case 'PageDown':
      case 'PageUp':
        return true;
      default:
        return false;
    }
  },
  isNotLogged: () => {
    return variables.user === null;
  },
  isRightLeft: event => {
    return (typeof event === 'object' && event.button === 0);
  },
  isRightClick: event => {
    return (typeof event === 'object' && event.button === 2);
  },
  isTouchStart: event => {
    return true;
  },
  isVisible: element => {
    return !element.hidden;
  },
  removeChilds: element => {
    while (element.firstChild) {
      element.removeChild(element.firstChild);
    }
  },
  screenBlocker: {
    create: () => {
      if (!Core.screenBlockerDiv) {
        Core.screenBlockerDiv = document.getElementById('screenBlocker');
        if (!Core.screenBlockerDiv) {
          Core.screenBlockerDiv = document.createElement("div");
          Core.screenBlockerDiv.id = 'screenBlocker';
          Core.screenBlockerDiv.style.position = "absolute";
          Core.screenBlockerDiv.style.top = "0px";
          Core.screenBlockerDiv.style.width = "100vw";
          Core.screenBlockerDiv.style.height = "100vh";
          Core.screenBlockerDiv.style.background = "gray";
          Core.screenBlockerDiv.style.opacity = ".7";
          Core.screenBlockerDiv.focus();
          document.body.appendChild(Core.screenBlockerDiv);
        }
      } else {
        Core.screenBlockerDiv.style.display = "block";
      }
    },
    block: () => {
      Core.screenBlocker.create();
      Core.screenBlockerDiv.style.display = "block";
    },
    unblock: (options) => {
      Core.screenBlocker.create();
      Core.screenBlockerDiv.style.display = "none";
      if (options && options.focus) {
        options.focus.focus();
      }
    }
  },
  sendGet: (url, origin) => {
    if (!origin) {
      throw new Error(`Invalid origin for sendGet: ${origin}`);
    }
    const requestId = Core.getNextRequestId();
    fetch(url, {
      headers: {
        "Content-Type": "application/json",
        "RequestId": requestId
      }
    })
            .then(function (response) {
              const headers = response.headers;
              const requestId = parseInt(headers.get('RequestId'));
              response.json().then(jsonData => {
                jsonData.requestId = requestId;
                Core.trigger(origin, 'response', jsonData);
              });
            })
            ;
    return {requestId};
  },
  sendPost: (url, origin, formObject) => {
    if (!origin) {
      throw new Error(`Invalid origin for sendGet: ${origin}`);
    }
    const requestId = Core.getNextRequestId();
    fetch(url, {
      method: "POST",
      cache: "no-cache",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "RequestId": requestId
      },
      redirect: "follow",
      body: JSON.stringify(formObject)
    })
            .then(function (response) {
              const headers = response.headers;
              const requestId = parseInt(headers.get('RequestId'));
              response.json().then(jsonData => {
                jsonData.requestId = requestId;
                Core.trigger(origin, 'response', jsonData);
              });
            })
            ;
    return {requestId};
  },
  sendPut: (url, origin, formObject) => {
    if (!origin) {
      throw new Error(`Invalid origin for sendGet: ${origin}`);
    }
    const requestId = Core.getNextRequestId();
    fetch(url, {
      method: "PUT",
      cache: "no-cache",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "RequestId": requestId
      },
      redirect: "follow",
      body: JSON.stringify(formObject)
    })
            .then(function (response) {
              const headers = response.headers;
              const requestId = parseInt(headers.get('RequestId'));
              response.json().then(jsonData => {
                jsonData.requestId = requestId;
                Core.trigger(origin, 'response', jsonData);
              });
            })
            ;
    return {requestId};
  },
  setMessagesContainer: target => {
    Core.messagesContainer = typeof target === 'string' ? document.getElementById(target) : target;
    console.log(`Set message container to ${Core.messagesContainer.id}`);
  },
  show: (id) => {
    const element = typeof id === 'string' ? document.getElementById(id) : id;
    element.hidden = false;
    Core.trigger(element, 'show');
//    const display = element.getAttribute('lastDisplay');
//    if (display) {
//      element.style.display = display;
//    } else {
//      element.style.display = '';
//    }
  },
  trigger: (target, eventName, detail) => {
    const event = new CustomEvent(eventName, {detail});
    target.dispatchEvent(event);
  },
  validateById: (id) => {
    if (id === null) {
      throw new Error(`You must specify a valid id: ${id}`);
    }
    const element = document.getElementById(id);
    if (element === null) {
      throw new Error(`Can't find the element with the id ${id}.`);
    }
    return element;
  },
  validateElement: (element) => {
    if (element === null) {
      throw new Error(`The parameter element is null.`);
    }
    if (!element.tagName) {
      throw new Error(`The node is not an element.`);
    }
    return element;
  },
  validateIdOrElement: (id, element) => {
    if (id === null && element === null) {
      throw new Error(`You must specify an id or element.`);
    }
    if (id !== null && element !== null && element.id !== id) {
      throw new Error(`The element and the id don't belong to the same element.`);
    }
    if (id !== null) {
      return Core.validateById(id);
    }
    if (element !== null) {
      return Core.validateElement(element);
    }
  }
};

window.onload = () => {
  Core.onloadFunctions.forEach(func => {
    func();
  });
  if (Core.pageParameters.has('section')) {
    Core.changeSection(Core.pageParameters.get('section'));
  }
};

// Library inputGenericValidator/0.1.0 addeded by system.
/*
 * Created on: 26/02/2020
 * Author:     Esteban Cabezudo
 */

/* global Core */

const inputGenericValidator = ({ element = null, id = null, getValidationURL = null, onValid = null, onNotValid = null, onKeyPress = null } = {}) => {
  let verificationTimer;
  let requestId = 0;

  const validateOptions = () => {
    if (element === null && id === null) {
      throw Error('You must define a property id or a property element.');
    }
    if (getValidationURL === null && Core.isFunction(getValidationURL)) {
      throw Error('You must set a function that returns a validation url.');
    }
  };
  const createGUI = () => {
    if (element === null) {
      element = Core.validateById(id);
    }
    element.className = 'inputGenericValidator';
    if (element.value && element.value.length > 0) {
      sendValidationRequest(element);
    }
  };
  const assignTriggers = () => {
    element.addEventListener('response', event => {
      const data = event.detail;

      const element = event.srcElement;
      if (requestId === data.requestId) {
        const data = event.detail;
        data.elementId = element.id;
        Core.showMessage(data);
        if (data.status === 'ERROR') {
          element.classList.add('error');
        }
        if (data.status === 'OK') {
          element.classList.remove('error');
          if (Core.isFunction(onValid)) {
            onValid();
          }
        } else {
          if (Core.isFunction(onNotValid)) {
            onNotValid();
          }
        }
      }
    });
    element.addEventListener("keypress", event => {
      if (Core.isFunction(onKeyPress)) {
        onKeyPress(event);
      }
    });
    element.addEventListener("keyup", event => {
      if (Core.isModifierKey(event) || Core.isNavigationKey(event)) {
        return;
      }
      if (verificationTimer) {
        clearTimeout(verificationTimer);
      }
      verificationTimer = setTimeout(sendValidationRequest(element), Core.EVENT_TIME_DELAY);
    });
  };
  const sendValidationRequest = element => {
    const response = Core.sendGet(getValidationURL(), element);
    requestId = response.requestId;
  };

  validateOptions();
  createGUI();
  assignTriggers();
}
;

// Library linkTo/0.1.0 addeded by system.
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global Core */

const linkTo = ({ onClick = null, id = null, element = null } = {}) => {
  const validateOptions = () => {
    if (id !== null) {
      element = Core.validateById(id);
    } else {
      if (element === null) {
        throw Error('You must define a property id or a property element.');
      }
    }
    if (onClick === null) {
      throw Error('You must define a url or function in a property onClick.');
    }
  };
  const createGUI = () => {
    element.classList.add('linkTo');
    element.onclick = () => {
      if (typeof onClick === 'function') {
        onClick(this);
      } else {
        document.location.href = onClick;
      }
    };
  };
  const assignTriggers = () => {
  };
  validateOptions();
  createGUI();
  assignTriggers();
}
;

// Library simpleStaticMessage/0.1.0 addeded by system.
/*
 * Created on: 29/10/2019
 * Author:     Esteban Cabezudo
 */

/* global Core */

const simpleStaticMessage = ({ id = null, element = null } = {}) => {
  const
          REMOVE_MESSAGE_TIME_DELAY = 3000;
  let
          defaultMessage,
          messageContainer,
          messageRemoverTimer;

  const validateOptions = () => {
    element = Core.validateIdOrElement(id, element);
  };
  const createGUI = () => {
    element.className = 'simpleStaticMessage';
    Core.setMessagesContainer(element);
    defaultMessage = element.innerHTML;
    Core.removeChilds(element);
    messageContainer = document.createElement('div');
    messageContainer.innerText = defaultMessage;
    element.appendChild(messageContainer);
  };
  const assignTriggers = () => {
    element.addEventListener('cleanMessages', () => {
      console.log('Clear messages.');
      messageContainer.innerText = '';
    });
    element.addEventListener('showMessage', event => {
      console.log('Show message.');
      const payload = event.detail;
      switch (payload.status) {
        case 'ERROR':
          element.classList.remove('green');
          element.classList.add('red');
          break;
        case 'OK':
          element.classList.remove('red');
          element.classList.add('green');
          break;
        default:
          throw new Error(`Invalid status: ${payload.status}`);
      }
      messageContainer.innerText = payload.message;
      if (messageRemoverTimer) {
        clearTimeout(messageRemoverTimer);
      }
      messageRemoverTimer = setTimeout(() => {
        element.className = 'simpleStaticMessage';
        messageContainer.innerText = defaultMessage;
      }, REMOVE_MESSAGE_TIME_DELAY);
    });
  };
  validateOptions();
  createGUI();
  assignTriggers();
  return element;
};

// created by system using manager/sites/add.html:12.
      {
        const createGUI = () => {
          const detailDiv = Core.validateById('detail');
          const siteName = Core.validateById('siteName');
          inputGenericValidator({
            element: siteName,
            getValidationURL: () => {
              return `/api/v1/sites/names/${siteName.value}/validate`;
            }
          });
          Core.screenBlocker.unblock();
          linkTo({onClick: 'sites.html', id: 'siteList'});
        };
        Core.addOnloadFunction(createGUI);
      }
// created by system using messages/section/simple/message.html:2 called from manager/sites/add.html:34
  (() => {
    const createGUI = () => {
      console.log('Create GUI for simpleStaticMessage:0.1.0');
      simpleStaticMessage({id: 'simpleStaticMessage'});
    };
    Core.addOnloadFunction(createGUI);
  })();
