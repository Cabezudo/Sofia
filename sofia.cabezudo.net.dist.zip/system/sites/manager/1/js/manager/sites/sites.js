const templateVariables = { "site": { "name": "Manager de Sofía", "shortName": "Manager" }, "themeName": "basic", "theme": { "application": { "container": { "width": { "default": "100vw", "480": "480px", "750": "750px", "1024": "1024px", "1250": "1250px", "1800": "1800px" } }, "color": { "main": "#000474" } }, "title": { "font": { "family": "Arial", "weight": { "default": "bold", "480": "bold", "750": "bold", "1024": "bold", "1250": "bold", "1800": "bold" }, "size": { "default": "26px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" }, "padding": { "default": "20px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "subtitle": { "font": { "family": "Arial", "weight": { "default": "bold", "480": "bold", "750": "bold", "1024": "bold", "1250": "bold", "1800": "bold" }, "size": { "default": "20px", "480": "20px", "750": "20px", "1024": "20px", "1250": "20px", "1800": "20px" }, "padding": { "default": "20px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "messages": { "font": { "family": "'Economica', sans-serif", "size": { "default": "20px", "480": "20px", "750": "20px", "1024": "20px", "1250": "20px", "1800": "20px" }, "padding": { "default": "20px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "text": { "font": { "family": "Roboto Condensed", "size": { "default": "18px", "480": "26px", "750": "26px", "1024": "26px", "1250": "26px", "1800": "26px" } } }, "caption": { "title": { "font": { "family": "Roboto Condensed", "size": { "default": "34px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } }, "option": { "font": { "family": "Roboto Condensed", "size": { "default": "18px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } }, "text": { "font": { "family": "Roboto Condensed", "size": { "default": "22px", "480": "48px", "750": "48px", "1024": "48px", "1250": "48px", "1800": "48px" } } } }, "button": { "red": { "color": "white", "backgroundColor": "#D11250" }, "orange": { "red": { "color": "white", "backgroundColor": "#DB5800" } }, "blue": { "red": { "color": "white", "backgroundColor": "#006899" } }, "green": { "red": { "color": "white", "backgroundColor": "#008F68" } } } }, "messages": { "message": { "default": "" } } };
// Library core/0.1.0 addeded by system.
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global fetch */
/* global postData */
/* global variables */

'use strict';
const Core = {
  messagesContainer: null,
  requestId: 0,
  onloadFunctions: [],
  screenBlockerDiv: null,
  pageParameters: new URLSearchParams(location.search),
  lastSection: null,
  showMessage: (messageObject) => {
    if (Core.messagesContainer !== null) {
      Core.trigger(Core.messagesContainer, 'showMessage', messageObject);
    } else {
      throw new Error('No messages container defined.');
    }
  },
  addOnloadFunction: (func) => {
    Core.onloadFunctions.push(func);
  },
  changeSection: section => {
    if (Core.lastSection !== null) {
      Core.hide(Core.lastSection);
      Core.show(section);
    }
  },
  cleanMessagesContainer: () => {
    if (Core.messagesContainer) {
      Core.trigger(Core.messagesContainer, 'cleanMessages');
    }
  },
  getNextRequestId: () => {
    return Core.requestId++;
  },
  getRequestId: () => {
    return Core.requestId;
  },
  getURLParameterByName: (name, url) => {
    if (!url) {
      url = window.location.href;
    }
    name = name.replace(/[\[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
    const results = regex.exec(url);
    if (!results) {
      return null;
    }
    if (!results[2]) {
      return '';
    }
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  },
  hide: (id) => {
    const element = typeof id === 'string' ? document.getElementById(id) : id;
    element.hidden = true;
    Core.trigger(element, 'hide');
//    if (!element.style.display) {
//      element.setAttribute('lastDisplay', element.style.display);
//    }
//    element.style.display = 'none';
  },
  isEnter: event => {
    return event.key === 'Enter';
  },
  isFunction: v => {
    return Object.prototype.toString.call(v) === '[object Function]';
  },
  isLogged: () => {
    return !Core.isNotLogged();
  },
  isModifierKey: event => {
    const key = event.key;
    switch (key) {
      case "Alt":
      case "AltGraph":
      case "CapsLock":
      case "Control":
      case "Fn":
      case "FnLock":
      case "Hyper":
      case "Meta":
      case "NumLock":
      case "ScrollLock":
      case "Shift":
      case "Super":
      case "Symbol":
      case "SymbolLock":
        return true;
      default:
        return false;
    }
  },
  isNavigationKey: event => {
    const key = event.key;
    switch (key) {
      case 'Up':
      case 'ArrowUp':
      case 'Right':
      case 'ArrowRight':
      case 'Down':
      case 'ArrowDown':
      case 'Left':
      case 'ArrowLeft':
      case 'End':
      case 'Home':
      case 'PageDown':
      case 'PageUp':
        return true;
      default:
        return false;
    }
  },
  isNotLogged: () => {
    return variables.user === null;
  },
  isRightLeft: event => {
    return (typeof event === 'object' && event.button === 0);
  },
  isRightClick: event => {
    return (typeof event === 'object' && event.button === 2);
  },
  isTouchStart: event => {
    return true;
  },
  isVisible: element => {
    return !element.hidden;
  },
  removeChilds: element => {
    while (element.firstChild) {
      element.removeChild(element.firstChild);
    }
  },
  screenBlocker: {
    create: () => {
      if (!Core.screenBlockerDiv) {
        Core.screenBlockerDiv = document.getElementById('screenBlocker');
        if (!Core.screenBlockerDiv) {
          Core.screenBlockerDiv = document.createElement("div");
          Core.screenBlockerDiv.id = 'screenBlocker';
          Core.screenBlockerDiv.style.position = "absolute";
          Core.screenBlockerDiv.style.top = "0px";
          Core.screenBlockerDiv.style.width = "100vw";
          Core.screenBlockerDiv.style.height = "100vh";
          Core.screenBlockerDiv.style.background = "gray";
          Core.screenBlockerDiv.style.opacity = ".7";
          Core.screenBlockerDiv.focus();
          document.body.appendChild(Core.screenBlockerDiv);
        }
      } else {
        Core.screenBlockerDiv.style.display = "block";
      }
    },
    block: () => {
      Core.screenBlocker.create();
      Core.screenBlockerDiv.style.display = "block";
    },
    unblock: (options) => {
      Core.screenBlocker.create();
      Core.screenBlockerDiv.style.display = "none";
      if (options && options.focus) {
        options.focus.focus();
      }
    }
  },
  sendGet: (url, origin) => {
    if (!origin) {
      throw new Error(`Invalid origin for sendGet: ${origin}`);
    }
    const requestId = Core.getNextRequestId();
    fetch(url, {
      headers: {
        "Content-Type": "application/json",
        "RequestId": requestId
      }
    })
            .then(function (response) {
              const headers = response.headers;
              const requestId = parseInt(headers.get('RequestId'));
              response.json().then(jsonData => {
                jsonData.requestId = requestId;
                Core.trigger(origin, 'response', jsonData);
              });
            })
            ;
    return {requestId};
  },
  sendPost: (url, origin, formObject) => {
    if (!origin) {
      throw new Error(`Invalid origin for sendGet: ${origin}`);
    }
    const requestId = Core.getNextRequestId();
    fetch(url, {
      method: "POST",
      cache: "no-cache",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "RequestId": requestId
      },
      redirect: "follow",
      body: JSON.stringify(formObject)
    })
            .then(function (response) {
              const headers = response.headers;
              const requestId = parseInt(headers.get('RequestId'));
              response.json().then(jsonData => {
                jsonData.requestId = requestId;
                Core.trigger(origin, 'response', jsonData);
              });
            })
            ;
    return {requestId};
  },
  sendPut: (url, origin, formObject) => {
    if (!origin) {
      throw new Error(`Invalid origin for sendGet: ${origin}`);
    }
    const requestId = Core.getNextRequestId();
    fetch(url, {
      method: "PUT",
      cache: "no-cache",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "RequestId": requestId
      },
      redirect: "follow",
      body: JSON.stringify(formObject)
    })
            .then(function (response) {
              const headers = response.headers;
              const requestId = parseInt(headers.get('RequestId'));
              response.json().then(jsonData => {
                jsonData.requestId = requestId;
                Core.trigger(origin, 'response', jsonData);
              });
            })
            ;
    return {requestId};
  },
  setMessagesContainer: target => {
    Core.messagesContainer = typeof target === 'string' ? document.getElementById(target) : target;
    console.log(`Set message container to ${Core.messagesContainer.id}`);
  },
  show: (id) => {
    const element = typeof id === 'string' ? document.getElementById(id) : id;
    element.hidden = false;
    Core.trigger(element, 'show');
//    const display = element.getAttribute('lastDisplay');
//    if (display) {
//      element.style.display = display;
//    } else {
//      element.style.display = '';
//    }
  },
  trigger: (target, eventName, detail) => {
    const event = new CustomEvent(eventName, {detail});
    target.dispatchEvent(event);
  },
  validateById: (id) => {
    if (id === null) {
      throw new Error(`You must specify a valid id: ${id}`);
    }
    const element = document.getElementById(id);
    if (element === null) {
      throw new Error(`Can't find the element with the id ${id}.`);
    }
    return element;
  },
  validateElement: (element) => {
    if (element === null) {
      throw new Error(`The parameter element is null.`);
    }
    if (!element.tagName) {
      throw new Error(`The node is not an element.`);
    }
    return element;
  },
  validateIdOrElement: (id, element) => {
    if (id === null && element === null) {
      throw new Error(`You must specify an id or element.`);
    }
    if (id !== null && element !== null && element.id !== id) {
      throw new Error(`The element and the id don't belong to the same element.`);
    }
    if (id !== null) {
      return Core.validateById(id);
    }
    if (element !== null) {
      return Core.validateElement(element);
    }
  }
};

window.onload = () => {
  Core.onloadFunctions.forEach(func => {
    func();
  });
  if (Core.pageParameters.has('section')) {
    Core.changeSection(Core.pageParameters.get('section'));
  }
};

// Library simpleList/0.1.0 addeded by system.
/* global Core, fetch */

/*
 * Created on: 14/05/2019
 * Author:     Esteban Cabezudo
 *
 */

const simpleList = async ({ id = null, source = null, filterInputElement = null, cellMaker = null, onClick = null, notLoggedURL = '/' } = {}) => {
  const LIST_CLASS_NAME = "simpleList";
  const SCROLL_TIME_TO_FETCH = 200;
  const RESIZE_TIME_TO_CALCULATE = 200;
  const MESSAGE_BASE_CLASS = "messageBaseClass";
  const MESSAGE_CLASS_MESSAGE = "message";
  const MESSAGE_CLASS_WARNING = "warning";
  const MESSAGE_CLASS_ERROR = "error";
  const NUMBER_OF_OFFSET_RECORDS = 10;
  const STATUS_ATTRIBUTE_NAME = "status";
  const STATUS_PENDING = "pending";
  const STATUS_COMPLETED = "completed";
  const MESSAGE_LOADING_DATA = "Cargando datos para crear lista.";
  const MESSAGE_CREATING_LIST = "Creando lista.";
  const MESSAGE_I_CAN_NOT_CREATE_THE_LIST = "Ha sucedido un error al cargar la lista. Intente mas tarde por favor.";
  const MESSAGE_NO_RECORD_FOUND = "No hay registros en la base de datos";
  const RELOAD_LIST_EVENT_TIME_DELAY = 800;
  let numberOfRecordsPerReading;
  let resizeTimer;
  let lastFilterInputValue = '';
  let reloadTimer;
  let fetchTimer;
  let listElement;
  let tableContainer;
  let filterInput = null;
  let table;
  let tableBody;
  let totalRecords;
  let bodyHeight;
  let rowHeight;
  let firstVisibleRowNumber;
  let lastVisibleRowNumber;
  let visibleRowsNumber;
  let tableScroll;
  const calculateValues = () => {
    bodyHeight = tableBody.offsetHeight;
    const firstRow = tableBody.firstChild;
    rowHeight = firstRow.offsetHeight;
    const tableContainerHeight = tableContainer.offsetHeight;
    visibleRowsNumber = parseInt(tableContainerHeight / rowHeight);
    tableScroll = tableContainer.scrollTop;
    firstVisibleRowNumber = Math.round(tableScroll / rowHeight);
    lastVisibleRowNumber = firstVisibleRowNumber + visibleRowsNumber;
  };
  const loadAllData = () => {
    loadData(firstVisibleRowNumber - NUMBER_OF_OFFSET_RECORDS);
    loadData(lastVisibleRowNumber + NUMBER_OF_OFFSET_RECORDS);
  };
  const loadData = async rowNumber => {
    if (rowNumber < 0) {
      rowNumber = 0;
    }
    const page = Math.floor(rowNumber / numberOfRecordsPerReading);
    const milestoneId = page * numberOfRecordsPerReading;
    if (milestoneId > totalRecords) {
      return;
    }
    const rowId = getRowId(milestoneId);
    const rowElement = document.getElementById(rowId);
    const state = rowElement.getAttribute(STATUS_ATTRIBUTE_NAME);
    if (state === null) {
      fetchData(rowElement, milestoneId);
    }
  };
  const fetchData = (rowElement, start) => {
    rowElement.setAttribute(STATUS_ATTRIBUTE_NAME, STATUS_PENDING);
    let url = `${source}?offset=${start}`;
    return fetch(url)
            .then(response => {
              if (response.ok) {
                return response.json();
              } else {
                return null;
              }
            })
            .then(data => {
              if (data === null) {
                createErrorMessage(MESSAGE_I_CAN_NOT_CREATE_THE_LIST);
                return;
              }
              data.list.forEach(elementData => {
                const rowId = getRowId(elementData.row);
                const tableRow = document.getElementById(rowId);
                addTableData(tableRow, elementData);
                if (Core.isFunction(onClick)) {
                  tableRow.className = 'clickable';
                  tableRow.onclick = event => {
                    onClick(event, elementData);
                  };
                }
              });
              rowElement.setAttribute(STATUS_ATTRIBUTE_NAME, STATUS_COMPLETED);
            });
  };
  const showRecord = recordNumber => {
    newScroll = recordNumber * rowHeight - bodyHeight / 2;
    tableContainer.scrollTop = newScroll;
    tableBodyScroll = newScroll;
  };
  const createMessage = message => {
    abstractMessageCreator(message, MESSAGE_CLASS_MESSAGE);
  };
  const createErrorMessage = message => {
    abstractMessageCreator(message, MESSAGE_CLASS_ERROR);
  };
  const abstractMessageCreator = (message, ...className) => {
    const divMessage = document.createElement("DIV");
    divMessage.classList.add(MESSAGE_BASE_CLASS);
    className.forEach(className => {
      divMessage.classList.add(className);
    });
    Core.removeChilds(tableContainer);
    tableContainer.appendChild(divMessage);
    const messageTextNode = document.createTextNode(message);
    divMessage.appendChild(messageTextNode);
  };
  const addEmptyRow = (rowId) => {
    const tableRow = document.createElement("TR");
    tableRow.id = getRowId(rowId);
    if (Core.isFunction(cellMaker)) {
      const innerHTML = cellMaker();
      tableRow.innerHTML = innerHTML;
    } else {
      removeChilds(tableRow);
      const tableData = document.createElement("TD");
      tableRow.appendChild(tableData);
      const textNode = document.createTextNode('\u00A0');
      tableData.appendChild(textNode);
    }
    tableBody.appendChild(tableRow);
  };
  const addTableData = (tableRow, row) => {
    if (Core.isFunction(cellMaker)) {
      const innerHTML = cellMaker(row);
      tableRow.innerHTML = innerHTML;
    } else {
      removeChilds(tableRow);
      Object.keys(row).forEach(field => {
        if (field === 'row' || field === 'id') {
          return;
        }
        const tableData = document.createElement("TD");
        tableRow.appendChild(tableData);
        const textNode = document.createTextNode(`${row[field]}`);
        tableData.appendChild(textNode);
      });
    }
  };
  const getRowId = rowId => {
    return `${id}:${rowId}`;
  };
  const removeChilds = element => {
    while (element.firstChild) {
      element.removeChild(element.firstChild);
    }
  };
  const validateOptions = () => {
    listElement = Core.validateById(id);
    if (filterInputElement !== null) {
      filterInput = Core.validateElement(filterInputElement);
      if (filterInput.tagName !== 'INPUT') {
        throw new Error(`Can't use a ${filterInput.tagName} as filter input.`);
      }
    }
  };
  const createGUI = async() => {
    tableContainer = document.createElement('DIV');
    listElement.className = LIST_CLASS_NAME;
    listElement.appendChild(tableContainer);
//    onresize(() => {
//      if (resizeTimer) {
//        clearTimeout(resizeTimer);
//      }
//      resizeTimer = setTimeout(() => {
//        calculateValues();
//      }, RESIZE_TIME_TO_CALCULATE);
//    });
    createMessage(MESSAGE_LOADING_DATA);
    loadTable();
  };
  const loadTable = () => {
    let url = source;
    if (filterInput !== null && filterInput.value !== lastFilterInputValue) {
      lastFilterInputValue = filterInput.value;
      url += `?filters=${encodeURIComponent(filterInput.value)}`;
    }
    tableContainer.scrollTop = 0;

    fetch(`${url}`)
            .then(response => {
              if (response.ok) {
                return response.json();
              } else {
                return null;
              }
            })
            .then(data => {
              if (data === null) {
                createErrorMessage(MESSAGE_I_CAN_NOT_CREATE_THE_LIST);
                return;
              }

              if (data.status === 'NOT_LOGGED_IN') {
                document.location.replace(notLoggedURL);
              }

              totalRecords = data.totalRecords;
              const filters = data.filters;
              if (filterInput !== null) {
                filterInput.value = filters;
                lastFilterInputValue = filters;
              }
              if (totalRecords === 0) {
                createMessage(MESSAGE_NO_RECORD_FOUND);
                return;
              }
              numberOfRecordsPerReading = data.pageSize;
              removeChilds(tableContainer);
              createMessage(MESSAGE_CREATING_LIST);
              table = document.createElement("TABLE");
              tableBody = document.createElement("TBODY");
              table.appendChild(tableBody);
              removeChilds(tableContainer);
              tableContainer.appendChild(table);
              tableContainer.onscroll = event => {
                calculateValues();
                if (fetchTimer) {
                  clearTimeout(fetchTimer);
                }
                fetchTimer = setTimeout(() => {
                  loadAllData();
                }, SCROLL_TIME_TO_FETCH);
              };
              for (let i = 0; i < totalRecords; i++) {
                addEmptyRow(i);
              }
              calculateValues();
              loadAllData();
            });
  };
  const assignTriggers = () => {
    if (filterInput !== null) {
      filterInput.addEventListener('setFilter', event => {
        const data = event.detail;
        filterInput.value = data;
        loadTable();
      });
      filterInput.addEventListener("keyup", event => {
        if (Core.isModifierKey(event) || Core.isNavigationKey(event)) {
          return;
        }
        if (reloadTimer) {
          clearTimeout(reloadTimer);
        }
        reloadTimer = setTimeout(loadTable, RELOAD_LIST_EVENT_TIME_DELAY);
      });
    }
  };
  validateOptions();
  assignTriggers();
  createGUI();
};

// Library linkTo/0.1.0 addeded by system.
/*
 * Created on: 30/10/2018
 * Author:     Esteban Cabezudo
 */

/* global Core */

const linkTo = ({ onClick = null, id = null, element = null } = {}) => {
  const validateOptions = () => {
    if (id !== null) {
      element = Core.validateById(id);
    } else {
      if (element === null) {
        throw Error('You must define a property id or a property element.');
      }
    }
    if (onClick === null) {
      throw Error('You must define a url or function in a property onClick.');
    }
  };
  const createGUI = () => {
    element.classList.add('linkTo');
    element.onclick = () => {
      if (typeof onClick === 'function') {
        onClick(this);
      } else {
        document.location.href = onClick;
      }
    };
  };
  const assignTriggers = () => {
  };
  validateOptions();
  createGUI();
  assignTriggers();
}
;

// Library simpleStaticMessage/0.1.0 addeded by system.
/*
 * Created on: 29/10/2019
 * Author:     Esteban Cabezudo
 */

/* global Core */

const simpleStaticMessage = ({ id = null, element = null } = {}) => {
  const
          REMOVE_MESSAGE_TIME_DELAY = 3000;
  let
          defaultMessage,
          messageContainer,
          messageRemoverTimer;

  const validateOptions = () => {
    element = Core.validateIdOrElement(id, element);
  };
  const createGUI = () => {
    element.className = 'simpleStaticMessage';
    Core.setMessagesContainer(element);
    defaultMessage = element.innerHTML;
    Core.removeChilds(element);
    messageContainer = document.createElement('div');
    messageContainer.innerText = defaultMessage;
    element.appendChild(messageContainer);
  };
  const assignTriggers = () => {
    element.addEventListener('cleanMessages', () => {
      console.log('Clear messages.');
      messageContainer.innerText = '';
    });
    element.addEventListener('showMessage', event => {
      console.log('Show message.');
      const payload = event.detail;
      switch (payload.status) {
        case 'ERROR':
          element.classList.remove('green');
          element.classList.add('red');
          break;
        case 'OK':
          element.classList.remove('red');
          element.classList.add('green');
          break;
        default:
          throw new Error(`Invalid status: ${payload.status}`);
      }
      messageContainer.innerText = payload.message;
      if (messageRemoverTimer) {
        clearTimeout(messageRemoverTimer);
      }
      messageRemoverTimer = setTimeout(() => {
        element.className = 'simpleStaticMessage';
        messageContainer.innerText = defaultMessage;
      }, REMOVE_MESSAGE_TIME_DELAY);
    });
  };
  validateOptions();
  createGUI();
  assignTriggers();
  return element;
};

// created by system using manager/sites/sites.html:13.
      {
        const createGUI = () => {
          simpleList({
            id: 'siteList',
            source: '/api/v1/sites',
            filterInputElement: null,
            cellMaker: row => {
              if (row) {
                return `<td>${row.name} (v${row.version})</td>`;
              }
            },
            onClick: (event, data) => {
              location.href = `/manager/sites/site.html?id=${data.id}`;
            },
            notLoggedURL: '/'
          });
        };
        Core.addOnloadFunction(createGUI);
      }
// created by system using sitesMenu.html:1 called from manager/sites/sites.html:38
  {
    const createGUI = () => {
      linkTo({onClick: '../index.html', id: 'home'});
      linkTo({onClick: 'add.html', id: 'addSite'});
    };
    Core.addOnloadFunction(createGUI);
  }
// created by system using messages/section/simple/message.html:2 called from manager/sites/sites.html:39
  (() => {
    const createGUI = () => {
      console.log('Create GUI for simpleStaticMessage:0.1.0');
      simpleStaticMessage({id: 'simpleStaticMessage'});
    };
    Core.addOnloadFunction(createGUI);
  })();
